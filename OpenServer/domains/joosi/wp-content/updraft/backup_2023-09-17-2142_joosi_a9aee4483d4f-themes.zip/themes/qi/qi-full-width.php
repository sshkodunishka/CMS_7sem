<?php
/*
Template Name: Qi Full Width
*/

get_header();

// Include content template
qi_template_part( 'content', 'templates/content' );

get_footer();

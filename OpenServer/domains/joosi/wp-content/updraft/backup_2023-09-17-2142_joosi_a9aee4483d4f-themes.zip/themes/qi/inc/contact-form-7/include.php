<?php

include_once QI_INC_ROOT_DIR . '/contact-form-7/helper.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
